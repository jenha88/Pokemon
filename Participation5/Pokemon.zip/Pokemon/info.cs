﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pokemon
{
    public class info
    {
        public List<info2> sprits { get; set; }
    }
}
